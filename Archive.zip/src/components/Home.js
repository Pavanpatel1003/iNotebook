import Notes from './Notes';

const Home = () => {

    return (
        <div>
            <Notes></Notes>
        </div>

    )
}

export default Home
